import fitz  # PyMuPDF

def pdf_to_txt(pdf_path, txt_path):
    doc = fitz.open(pdf_path)  # Abre el archivo PDF
    text = ""

    # Itera por todas las páginas del PDF
    for page_num in range(doc.page_count):
        page = doc.load_page(page_num)  # Carga la página
        text += page.get_text()  # Extrae el texto de la página

    # Guarda el texto extraído en un archivo .txt
    with open(txt_path, 'w', encoding='utf-8') as txt_file:
        txt_file.write(text)

    print(f"Texto extraído guardado en {txt_path}")

# Ejemplo de uso
pdf_to_txt("./michigan.pdf", "michigan.txt")
